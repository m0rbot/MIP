#include <stdlib.h>
#include "include/board.h"

// Pour décider de la version de fonction main à compiler
#define MAIN1


#ifdef MAIN1
/****************************************************************
 * MAIN1 : configuration de
 *         - LED_GREEN    : PC7,
 *         - SWITCH_LEFT  : PC1,
 *         - SWITCH_RIGHT : PC0
 *         par utilisation directe des registres de _GPIOC
 ****************************************************************/
void green_led(uint32_t on) {
	/* A COMPLETER */
}

uint32_t input(void) {
    return 0 /* A REMPLACER */;
}

int main(void)
{
	/* DECOMMENTER ET COMPLETER *
	/*
	// Enable clock for GPIOC to be able to use it
	_RCC->AHB1ENR = 
	
	// Configure inputs SW_LEFT (PC1) and SW_RIGHT (PC0)
	_GPIOC->MODER = 
	_GPIOC->PUPDR = 
	
	// Configure output LED_GREEN (PC7)
	_GPIOC->MODER = 
	_GPIOC->PUPDR = 
	_GPIOC->OTYPER = 
	_GPIOC->OSPEEDR = 
	*/
	
	green_led(0);
	
	while (1) {
		/* A COMPLETER */
	}
	return 0;
}
#endif

#ifdef MAIN2
/****************************************************************
 * MAIN2 : configuration de
 *         - LED_GREEN    : PC7,
 *         - SWITCH_LEFT  : PC1,
 *         - SWITCH_RIGHT : PC0
 *         par utilisation l'API de "lib/io.h"
 ****************************************************************/
#include "lib/io.h"

void green_led(uint32_t on) {
	/* A COMPLETER avec io_set/io_clear*/
}

uint32_t input(void) {
//    return io_read(A COMPLETER);
}

int main(void)
{	
	// Configure inputs SW_LEFT (PC1) and SW_RIGHT (PC0)
	// io_configure(A COMPLETER, NULL);
	
	// Configure output LED_GREEN (PC7)
	// io_configure(A COMPLETER, NULL);
	
	green_led(0);
	
	while (1) {
		/* A COMPLETER */
	}
	return 0;
}
#endif

#ifdef MAIN3
/****************************************************************
 * MAIN3 : configuration des leds RGB et des boutons du joystick
 *         par utilisation l'API de "libshield/libshield.h"
 ****************************************************************/
#include "libshield/libshield.h"

/* poor's man delay ... */
static void delay(int d_ms)
{
	int count=d_ms*((int)sysclks.ahb_freq/10/1000);
	for (int i=0; i<count ; i++) {
		__ASM volatile ("nop");
	}
}

int main(void)
{
	int blue_state=0;
	
	/* Initialize IO ports */
	libshield_init();
	
	/*** test leds ***/
	leds(LED_RED);							// red led only
	delay(1000);
	leds(LED_GREEN);						// green led only
	delay(1000);
	leds(LED_BLUE);							// blue led only
	delay(1000);
	leds(LED_RED | LED_GREEN | LED_BLUE);	// white color
	delay(1000);
	leds(0);								// leds turned off
	delay(1000);
	//function red_led
	red_led(1);								// red led only    
	delay(1000);
	red_led(0);
	//function green_led
	green_led(1);							// green led only
	delay(1000);
	green_led(0);
	//function blue_led
	blue_led(1);							// blue led only
	delay(1000);
	blue_led(0);
	
	/*** test joystick input ***/
	while (1) {

		/* A COMPLETER */

		delay(5);
	}
	return 0;
}

#endif
