#include "lib/io.h"
#include "include/config.h"
#include "leds.h"

/* led RGB :
 *   LED_RED   --> PB4
 *   LED_GREEN --> PC7
 *   LED_BLUE  --> PA9
 */
#define LED_RED_MASK	(1 << 4)
#define LED_GREEN_MASK	(1 << 7)
#define LED_BLUE_MASK	(1 << 9)
#define LED_RED_OFST    4
#define LED_GREEN_OFST  7
#define LED_BLUE_OFST   9

uint32_t leds_init(void)
{
	// Configure output LED_RED   --> PB4
    	io_configure(LED_RED_GPIO_PORT, LED_RED_MASK, LED_RED_GPIO_CFG, NULL);

    	// Configure output LED_BLUE  --> PA9
    	io_configure(LED_BLUE_GPIO_PORT, LED_BLUE_MASK, LED_BLUE_GPIO_CFG, NULL);

    	// Configure output LED_GREEN --> PC7
    	io_configure(LED_GREEN_GPIO_PORT, LED_GREEN_MASK, LED_GREEN_GPIO_CFG, NULL);
	
    	return 0;    
}

void leds(uint16_t val)
{
	red_led(val & (1<<2));
	green_led(val & (1<<1));
	blue_led(val & 0x1);
}

void red_led(uint32_t on)
{
	if(on)
		io_clear(LED_RED_GPIO_PORT, LED_RED_MASK);
	else
		io_set(LED_RED_GPIO_PORT, LED_RED_MASK);
}

void green_led(uint32_t on)
{
	if(on)
		io_clear(LED_GREEN_GPIO_PORT, LED_GREEN_MASK);
	else
		io_set(LED_GREEN_GPIO_PORT, LED_GREEN_MASK);
}

void blue_led(uint32_t on)
{
	if(on)
		io_clear(LED_BLUE_GPIO_PORT, LED_BLUE_MASK);
	else
		io_set(LED_BLUE_GPIO_PORT, LED_BLUE_MASK);
}
