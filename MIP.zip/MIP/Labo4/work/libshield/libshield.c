#include "libshield.h"

void libshield_init(void)
{
	leds_init();
	red_led(0);
	green_led(0);
	blue_led(0);
	sw_init();
}
