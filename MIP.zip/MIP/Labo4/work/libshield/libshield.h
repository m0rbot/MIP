#ifndef _LIBSHIELD_
#define _LIBSHIELD_

#include <stdint.h>

#include "leds.h"
#include "sw.h"

void libshield_init(void);

#endif
