#include "lib/io.h"
#include "include/config.h"
#include <stdint.h>
#include "sw.h"


/* switches
 *   SW_RIGHT  --> PC0
 *   SW_LEFT   --> PC1
 *   SW_UP     --> PA4
 *   SW_DOWN   --> PB0
 *   SW_CENTER --> PB5
 */
 
#define SW_RIGHT_MASK   (1<<0)
#define SW_RIGHT_OFST   (0)
#define SW_LEFT_MASK    (1<<1)
#define SW_LEFT_OFST    (1)
#define SW_UP_MASK      (1<<4)
#define SW_UP_OFST      (4)
#define SW_DOWN_MASK    (1<<0)
#define SW_DOWN_OFST    (0)
#define SW_CENTER_MASK  (1<<5)
#define SW_CENTER_OFST  (5)


uint32_t sw_init(void)
{
	// Configure input SW_UP     --> PA4
	io_configure(SW_UP_GPIO_PORT, SW_UP_MASK, SW_UP_GPIO_CFG, NULL);
	// Configure input SW_DOWN   --> PB0,
	io_configure(SW_DOWN_GPIO_PORT, SW_DOWN_MASK, SW_DOWN_GPIO_CFG, NULL);
	// Configure input SW_CENTER --> PB5
	io_configure(SW_CENTER_GPIO_PORT, SW_CENTER_MASK, SW_CENTER_GPIO_CFG, NULL);
	// Configure input SW_RIGHT  --> PC0, 
	io_configure(SW_RIGHT_GPIO_PORT, SW_RIGHT_MASK, SW_RIGHT_GPIO_CFG, NULL);
	// Configure input SW_LEFT   --> PC1
	io_configure(SW_LEFT_GPIO_PORT, SW_LEFT_MASK, SW_LEFT_GPIO_CFG, NULL);
	

    return 0;    
}

uint32_t sw_input(void)
{
	uint32_t switch_value=0;
	if(sw_right())
		switch_value |= (1<<0);
	if(sw_left()) 
		switch_value |= (1<<1);
	if(sw_up())
		switch_value |= (1<<2);
	if(sw_down())
		switch_value |= (1<<3);
	if(sw_center())
		switch_value |= (1<<4);

	return switch_value;
}

uint32_t sw_right(void)
{
	static uint16_t btn_state = 0;
	btn_state = ((btn_state<<1) | (((io_read(SW_RIGHT_GPIO_PORT, SW_RIGHT_MASK)) >> SW_RIGHT_OFST) & 1)) & 0x3FFF;
	if (btn_state == 0x1FFF) return 1;
	return 0;
}

uint32_t sw_left(void)
{
	static uint16_t btn_state = 0;
	btn_state = ((btn_state<<1) | (((io_read(SW_LEFT_GPIO_PORT, SW_LEFT_MASK)) >> SW_LEFT_OFST) & 1)) & 0x3FFF;
	if (btn_state == 0x1FFF) return 1;
	return 0;
}

uint32_t sw_up(void)
{
	static uint16_t btn_state = 0;
	btn_state = ((btn_state<<1) | (((io_read(SW_UP_GPIO_PORT, SW_UP_MASK)) >> SW_UP_OFST) & 1)) & 0x3FFF;
	if (btn_state == 0x1FFF) return 1;
	return 0;
}

uint32_t sw_down(void)
{
	static uint16_t btn_state = 0;
	btn_state = ((btn_state<<1) | (((io_read(SW_DOWN_GPIO_PORT, SW_DOWN_MASK)) >> SW_DOWN_OFST) & 1)) & 0x3FFF;
	if (btn_state == 0x1FFF) return 1;
	return 0;
}

uint32_t sw_center(void)
{
	static uint16_t btn_state = 0;
	btn_state = ((btn_state<<1) | (((io_read(SW_CENTER_GPIO_PORT, SW_CENTER_MASK)) >> SW_CENTER_OFST) & 1)) & 0x3FFF;
	if (btn_state == 0x1FFF) return 1;
	return 0;
}
