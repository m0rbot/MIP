#include <stdint.h>
#include <stdlib.h>
#include "include/board.h"

// Pour décider de la version de fonction main à compiler
#define MAIN3


#ifdef MAIN1
/****************************************************************
 * MAIN1 : configuration de
 *         - LED_GREEN    : PC7,
 *         - SWITCH_LEFT  : PC1,
 *         - SWITCH_RIGHT : PC0
 *         par utilisation directe des registres de _GPIOC
 ****************************************************************/
void green_led(uint32_t on) {
	/* A COMPLETER */
	if(on){
		_GPIOC->BSRR = 1 << 23;		// La broche PC7 au niveau bas (allumer la LED)
	}else{
		_GPIOC->BSRR = 1 << 7;		// La broche PC7 au niveau haut (etteindre la LED)
	}
}

uint32_t input(void) {
    return _GPIOC->IDR & 0x3;
}

int main(void)
{
	
	// Enable clock for GPIOC to be able to use it
	_RCC->AHB1ENR |= 1<<2; //0x4
	
	// Configure inputs SW_LEFT (PC1) and SW_RIGHT (PC0)
	_GPIOC->MODER = _GPIOC->MODER & 0xfffffff0;
	_GPIOC->PUPDR = _GPIOC->PUPDR & 0xfffffff0;
	
	// Configure output LED_GREEN (PC7)
	_GPIOC->MODER = (_GPIOC->MODER & 0xffff3fff) | 1<<14; 
	_GPIOC->PUPDR = _GPIOC->PUPDR & 0xffff3fff;
	_GPIOC->OTYPER = _GPIOC->OTYPER & 0xff7f;
	_GPIOC->OSPEEDR = (_GPIOC->OSPEEDR & 0xffff3fff) | 1<<14;

	green_led(0); //LED initialement etteint
	
	while (1) {
		if(input() & 0x1){	//SW_RIGHT
			green_led(1);
		}else if(input() & 0x2){ //SW_LEFT
			green_led(0);
		}
	}
	return 0;
}
#endif

#ifdef MAIN2
/****************************************************************
 * MAIN2 : configuration de
 *         - LED_GREEN    : PC7,
 *         - SWITCH_LEFT  : PC1,
 *         - SWITCH_RIGHT : PC0
 *         par utilisation l'API de "lib/io.h"
 ****************************************************************/
#include "lib/io.h"

void green_led(uint32_t on) {
	if(on)
		io_clear(_GPIOC, (1<<7));
	else
		io_set(_GPIOC, (1<<7));
}

uint32_t input(void) {
	return io_read(_GPIOC, 0x3);
}

int main(void)
{	
	// Configure inputs SW_LEFT (PC1) and SW_RIGHT (PC0)
	io_configure(_GPIOC, 0x3, (0x0<<16) | (0x0<<8), NULL);
	
	// Configure output LED_GREEN (PC7)
	io_configure(_GPIOC, 1<<7 , (0x1<<16) | (0x0<<8) | (0x0<<6) | (0x1<<4), NULL);
	
	green_led(0);
	
	while (1) {
		if(input()&0x1)
			green_led(1);
		else if(input()&0x2)
			green_led(0);
		
	}
	return 0;
}
#endif

#ifdef MAIN3
/****************************************************************
 * MAIN3 : configuration des leds RGB et des boutons du joystick
 *         par utilisation l'API de "libshield/libshield.h"
 ****************************************************************/
#include "libshield/libshield.h"

/* poor's man delay ... */
static void delay(int d_ms)
{
	int count=d_ms*((int)sysclks.ahb_freq/10/1000);
	for (int i=0; i<count ; i++) {
		__ASM volatile ("nop");
	}
}

int main(void)
{
	int blue_state=0;
	
	/* Initialize IO ports */
	libshield_init();
	
	/*** test leds ***/
	leds(LED_RED);							// red led only
	delay(1000);
	leds(LED_GREEN);						// green led only
	delay(1000);
	leds(LED_BLUE);							// blue led only
	delay(1000);
	leds(LED_RED | LED_GREEN | LED_BLUE);	// white color
	delay(1000);
	leds(0);								// leds turned off
	delay(1000);
	//function red_led
	red_led(1);								// red led only    
	delay(1000);
	red_led(0);
	//function green_led
	green_led(1);							// green led only
	delay(1000);
	green_led(0);
	//function blue_led
	blue_led(1);							// blue led only
	delay(1000);
	blue_led(0);
	
	/*** test joystick input ***/
	while (1) {
		uint32_t switch_value = sw_input();
		if(switch_value & 0x1){	//sw_right
			green_led(1);
		}
		if (switch_value & (1<<1)) { //sw_left
			green_led(0);
		}
		if (switch_value & (1<<2)) {	//sw_up
			red_led(1);
		}
		if (switch_value & (1<<3)) {	//sw_down
			red_led(0);
		}
		if (switch_value & (1<<4)) {	//sw_center
			//isON ? blue_led(0):blue_led(1);
			if(blue_state == 0){
				blue_led(1);
				blue_state = !blue_state;
			}else{
				blue_led(0);
				blue_state = !blue_state;
			}
			// if(blue_state == 1) blue_led(0) \ else blue_led(1); blue_state = not(blue_state);
			
		}
		delay(5);
	}
	return 0;
}

#endif
