#ifndef _ALLOC_H_
#define _ALLOC_H_

void   minit();
/*
void * malloc(unsigned int req);
int    free(void* mem);
*/
#endif
